<?PHP 
//added to admin pages to stop people without pass from viewing
session_start();
if(!isset($_SESSION["adminpass"])){
	header("Location: logout.php");
}
?>
