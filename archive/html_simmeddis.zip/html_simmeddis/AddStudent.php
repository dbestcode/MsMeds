<?php 
session_start();
if(isset($_GET['submit'])) 
{ 
    
		$file = fopen("./csv/students.csv", "a");
		echo $_SESSION["ncode"] . "," . $_GET["fname"] . "," . $_GET["lname"] . "," . date("d-m-Y");
		fputcsv($file, array($_SESSION["ncode"],$_GET["fname"],$_GET["lname"],date("m-d-Y")));

		fclose($file);
		$name = $_GET['name'];
		echo "User Has submitted the form and entered this name : <b> $name </b>";
		header("Location: index.php");
	

}

if(isset($_GET["barcode"])){
	if (strpos($_GET["barcode"], "edId") == 1) {//vaildidate that the barcode starts with MedId
	$_SESSION["ncode"] = $_GET["barcode"];
	} else {
		echo "invaild Barcode ID";
		header("Location: index.php");
	}
}
?>

<html>
<head>
	<title>SimMedDispense</title>
	<meta http-equiv="content-type" content="text/html;charset=utf-8" />
	<meta name="generator" content="Geany 1.22" />
	<link rel="stylesheet" type="text/css" href="css/layout.css"/>
	<link rel="stylesheet" href="css/w3mobile.css">
	
</head>

<body>
<div id="ccontainer">
	<div id="ccontainer">
	<div id="header">
		<div id="ccontainer" style="float:left"><img src="img/logo.gif" height=90px style="float:left"></div>
	</div>
	
	</div>
	<div id="ccontainer" style="width:60%; margin:0 auto">
		
		<div id="lilheader">
		<h1 style="font-size:40px;text-align:center;font-family:helvetica, serif;">Simulation Medication Dispensing System</h1>	
		</div>
			
	<div id="container" >
		<div id="content">
		
		<form method="GET" action="<?php echo $_SERVER['PHP_SELF']; ?>">
		<H2>Register New User</H2>
		<table>
		<tr><td>BarCode:</td><td><?PHP echo $_GET["barcode"]; ?></td></tr>
		<tr><td>First Name:</td><td><input type="text" name="fname"></td></tr>
		<tr><td>Last Name:</td><td><input type="text" name="lname"></td></tr>
		<tr><td><a href='index.php' style='
  background-color: #20285b;
  border: none;
  color: white;
  padding: 16px 32px;
  text-decoration: none;
  margin: 4px 2px;
  cursor: pointer;
'>Cancel</a></td><td><input type="submit" name="submit" value="Submit Form"></td></tr>
		</table>
</form>






		</div>
		<div id="footer">
		<?php include 'footer.php';?>
		</div>
	</div>
	</div>
</div>
</body>

</html>
