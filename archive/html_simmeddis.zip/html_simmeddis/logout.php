<?php
session_start();
?>
<meta http-equiv="refresh" content="1;url=index.php"> 
<!DOCTYPE html>
<html>
<body>

<?php
// remove all session variables
session_unset();

// destroy the session
session_destroy();

echo "You have been logged out."
?>

</body>
</html>
