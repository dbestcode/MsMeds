
<p></p>
<P style='text-align:center'>Please call the Pharmacy for any issue with this system<br><br>©2019 Pennsylvania College of Health Sciences Simulation Lab | All Rights Reserved </P>
		<?php 
				echo "<p style='text-align:right'>" . date("m-d-Y h:i A") . "</p>";
			?>
