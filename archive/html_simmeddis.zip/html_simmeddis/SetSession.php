<meta http-equiv="refresh" content="1;url=index.php"> 

<html>
<head>
	<title>SimMedDispense</title>
	<meta http-equiv="content-type" content="text/html;charset=utf-8" />
	<meta name="generator" content="Geany 1.22" />
	<link rel="stylesheet" type="text/css" href="css/layout.css"/>
	<link rel="stylesheet" href="css/w3mobile.css">
	
</head>

<body>
<div id="ccontainer">
	<div id="ccontainer">
	<div id="header">
		<div id="ccontainer" style="float:left"><img src="img/logo.gif" height=90px style="float:left"></div>
	</div>
	
	</div>
	<div id="ccontainer" style="width:60%; margin:0 auto">
		
		<div id="lilheader">
		<h1 style="font-size:40px;text-align:center;font-family:helvetica, serif;">Simulation Medication Dispensing System</h1>	
		</div>
			
	<div id="container" >
		
		<div id="content">
			<?php
			
			session_start();
			if ($_POST["uid"] == "nicholai"){
				$_SESSION["adminpass"] = "1";
				header("Location: Administrator.php");
				exit;
			}
			//check for userID
			if(isset($_POST["uid"])) {
				echo "Finding user ID...<br>";
				if (($handle = fopen("./csv/students.csv", "r")) !== FALSE) {
					while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
						if ($data[0] == $_POST["uid"]){
							echo "User Found...";
							$_SESSION["NurseID"] = $data[1] . "-" . $data[2];
						}
					}
					fclose($handle);
				}
				//if id not found goto addsutdent page
				if(!isset($_SESSION["NurseID"])){
					header("Location: AddStudent.php?barcode=" . $_POST["uid"]);
					exit;
				}
			}
			//check for patient ID
			if(isset($_POST["ptid"])) {
				echo "Finding Patient...<br>";
				if (($handle = fopen("./csv/patients.csv", "r")) !== FALSE) {
					while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
						if ($data[2] == $_POST["ptid"]){
							echo "Patient Found...";
							$_SESSION["PatientID"] = $data[1] . "-" . $data[0];
							$_SESSION["PatientMAR"] = $data[0] . "-" . $data[1] . "-MAR.pdf";
						}
					}
					fclose($handle);
				}
			}
			/*if(!isset($_SESSION["PatientID"])){
				echo "";
				echo '<script language="javascript">';
				echo 'alert("Not a vaild patient ID.")';
				echo '</script>';
			}*/
			echo "<br>Redirecting...";
		?>
		</div>
		<div id="footer">
		<?php include 'footer.php';?>
		</div>
	</div>
	</div>
</div>
</body>

</html>
