<?php 
echo "ID is ";
if (strpos("Medd4321", "edId") == 1) {
	echo "vaild";
} else {
	echo "invaild";
}
echo "<br>" . strpos("MeId4321", "edId");
?>


