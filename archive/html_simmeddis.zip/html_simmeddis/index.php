<?php

function CheckSession(){
	if (isset($_SESSION["NurseID"])) {
		if (isset($_SESSION["PatientID"])) {
				/* Redirect browser */
				header("Location: OpenPatient.php");
				exit;

		} else {
			echo "<br><h2 style='text-align:center'>Welcome " . $_SESSION["NurseID"] . "!</h2>";
			//echo ("<br><a href='logout.php' style='text-align:center;display:block;background-color:#fa661c;width:160px;padding:10px'>Log off</a>");
			echo ("<p>Please scan or type the Patient ID or MAR");
			echo ("<br><form name='input' action='SetSession.php' method='post'><input type='text' name='ptid' autofocus></form></p>");
		}
	} else {
		echo ("<p>Please scan your ID now.");
		echo ("<br><form name='input' action='SetSession.php' method='post'><input type='text' name='uid' autofocus></form></p>");
	}
}

session_start();
ini_set('display_errors', '1');
error_reporting(E_ALL);

if(isset($_POST["uid"])) {
	$_SESSION["NurseID"] = $_POST["uid"];
}
?>
<html>

<head>
	<title>SimMedDispense</title>
	<meta http-equiv="content-type" content="text/html;charset=utf-8" />
	<meta name="generator" content="Geany 1.22" />
	<link rel="stylesheet" type="text/css" href="css/layout.css"/>
	<link rel="stylesheet" href="css/w3mobile.css">
	
</head>

<body>
<div id="ccontainer">
	<div id="ccontainer">
	<div id="header">
		<div id="ccontainer" style="float:left"><img src="img/logo.gif" height=90px style="float:left"></div>
	</div>
	
	</div>
	<div id="ccontainer" style="width:60%; margin:0 auto">
		
		<div id="lilheader">
		<h1 style="font-size:40px;text-align:center;font-family:helvetica, serif;">Simulation Medication Dispensing System</h1>	
		</div>
			
	<div id="container" >
		<?php 
		if (isset($_SESSION["NurseID"])) {
			echo "<h3>User: <strong>" . $_SESSION["NurseID"] . "</strong></h3>";
			echo "<br><a href='logout.php' style='text-align:right;background-color:#fa661c;padding:5px'>Log off</a>";
		}
			?>
		<div id="content">
		
			<?php CheckSession(); ?>	
		</div>
		<div id="footer">
		<?php include 'footer.php';?>
		</div>
	</div>
	</div>
</div>
</body>

</html>
